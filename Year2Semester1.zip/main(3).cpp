#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <cmath>
#include <math.h>
#include <SDL_image.h>
#include <complex.h>

void putPixel(SDL_Renderer *renderer, float x, float y, unsigned char r, unsigned char g, unsigned char b)
{
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}

float squareWave(float t, float n)
{
    return(sin((2*n-1)*t)/(2*n-1));
}

double _Complex *fourier(double _Complex *in, double _Complex *out, int N)
{    
    int n; //index of in array
    int k; //index of out array
    
    for (k = 0; k < N; k++)
    {
        for (n = 0; n < N; n++)
        {
            out[k] += in[n] * cexp(-I*(2*M_PI*n) / N * k);
        }     
    }
    return out;
}

auto main() -> int
{
    constexpr int WindowWidth = 400;
    constexpr int WindowHeight = 300;
    SDL_Event event;
    SDL_Renderer *renderer;
    SDL_Window *window;
    SDL_Surface* image;
    int x;
    int i;
    std::random_device rd;
    SDL_Init(SDL_INIT_VIDEO);
    SDL_CreateWindowAndRenderer(WindowWidth, WindowHeight, 0, &window, &renderer);
    SDL_SetWindowTitle(window, "Put Pixel");
    // clear to background
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    bool quit = false;
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);

    //create complex arrays
    double _Complex *totalA = new double _Complex[WindowWidth]; //stores values of signal wave (time domain)
    double _Complex *totalB = new double _Complex[WindowWidth]; //stores values of frequency spectrum (frequency domain)

    //store and display square wave
    for (x = 0; x < WindowWidth; x++)
    {
        //store
        for (i = 1; i < 512; i++)
            totalA[x] += squareWave(x/25.0, i);
        //display
        putPixel(renderer, x, creal(totalA[x]) * 75 + 150, 255, 255, 0);
    }
    
    //fourier transform
    totalB = fourier(totalA, totalB, WindowWidth);
    
    //display frequency spectrum
    for (x = 0; x < WindowWidth; x++)
    {
        putPixel(renderer, x, creal(totalB[x]) + WindowWidth/2, 255, 0, 0); 
    }

    while (!quit)
    {
        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            // this is the window x being clicked.
            case SDL_QUIT:
                quit = true;
                break;
            // now we look for a keydown event
            case SDL_KEYDOWN:
            {
                switch (event.key.keysym.sym)
                {
                // if it's the escape key quit
                case SDLK_ESCAPE:
                    quit = true;
                    break;
                default:
                    break;
                } // end of key process
            }     // end of keydown
            break;
            default:
                break;
            } // end of event switch
        }     // end of poll events
        // flip buffers
        SDL_RenderPresent(renderer);
        // wait 100 ms
        SDL_Delay(100);
    }
    // clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return EXIT_SUCCESS;
}