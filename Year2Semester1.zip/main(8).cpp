#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <SDL_image.h>

void putPixel(SDL_Renderer *renderer, int x, int y, unsigned char r, unsigned char g, unsigned char b)
{
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}

void drawBox(SDL_Renderer *renderer,int startx,int starty,int endx, int endy)
{
    SDL_RenderDrawLine(renderer,startx,starty,startx,endy);
    SDL_RenderDrawLine(renderer,startx,starty,endx,starty);
    SDL_RenderDrawLine(renderer,endx,endy,endx,starty);
    SDL_RenderDrawLine(renderer,endx,endy,startx,endy);
}

auto main() -> int
{
    constexpr int WindowWidth = 1000;
    constexpr int WindowHeight = 900;
    SDL_Event event;
    SDL_Renderer *renderer;
    SDL_Window *window;
    SDL_Surface* image;
    int i;
    SDL_Surface* pScreenShot = SDL_CreateRGBSurface(0, WindowWidth, WindowHeight, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);
    std::random_device rd;
    std::mt19937 gen(rd());
    // create a distribution to produce our 2d points
    std::uniform_int_distribution<> width_dist(0, WindowWidth - 1);
    std::uniform_int_distribution<> height_dist(0, WindowHeight - 1);
    // create a distribution to produce our colour range
    // note windows does not allow an unsigned char dist see
    // https://stackoverflow.com/questions/31460733/why-arent-stduniform-int-distributionuint8-t-and-stduniform-int-distri
    std::uniform_int_distribution<unsigned short> colour_dist(0, 255);
    SDL_Init(SDL_INIT_VIDEO);
    SDL_CreateWindowAndRenderer(WindowWidth, WindowHeight, 0, &window, &renderer);
    SDL_SetWindowTitle(window, "Put Pixel");
    // clear to background
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    bool quit = false;
    while (!quit)
    {

        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            // this is the window x being clicked.
            case SDL_QUIT:
                quit = true;
                break;
            // now we look for a keydown event
            case SDL_KEYDOWN:
            {
                switch (event.key.keysym.sym)
                {
                // if it's the escape key quit
                case SDLK_ESCAPE:
                    quit = true;
                    break;
                case SDLK_s:
                    if(pScreenShot)
                    {
                        // Read the pixels from the current render target and save them onto the surface
                        SDL_RenderReadPixels(renderer, NULL, SDL_GetWindowPixelFormat(window), pScreenShot->pixels, pScreenShot->pitch);

                        // Create the bmp screenshot file
                        SDL_SaveBMP(pScreenShot, "Screenshot.bmp");
                        // Destroy the screenshot surface
                        SDL_FreeSurface(pScreenShot);
                    } 
                default:
                    break;
                } // end of key process
            }     // end of keydown
            break;
            default:
                break;
            } // end of event switch
        }     // end of poll events
        // clear to black
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
        SDL_RenderClear(renderer);
        //CREATE A purple line
        SDL_SetRenderDrawColor(renderer, 140, 30, 140, 255);
        SDL_RenderDrawLine(renderer,100,100,400,400);
        drawBox(renderer,50,50,100, 100);
        // flip buffers
        SDL_RenderPresent(renderer);


        
        // wait 100 ms
        SDL_Delay(100);
    }
    // clean up
    
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return EXIT_SUCCESS;
}