#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <SDL_image.h>

/*void putPixel(SDL_Renderer *renderer, int x, int y, unsigned char r, unsigned char g, unsigned char b)
{
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}*/

/////////////////////////////////////////////////////////////////////////////////////////TASK1

/*void drawBox(SDL_Renderer *renderer,int startx,int starty,int endx, int endy)
{
    SDL_RenderDrawLine(renderer,startx,starty,startx,endy);
    SDL_RenderDrawLine(renderer,startx,starty,endx,starty);
    SDL_RenderDrawLine(renderer,endx,endy,endx,starty);
    SDL_RenderDrawLine(renderer,endx,endy,startx,endy);
}*/
//////////////////////////////////////////////////////////////////////////////////////////TASK 4    

/*float f(float x)// num val used to plot out sine function
{
    
    return sin(x);
}
float delta=0.001;//chang change this dosent matter
float df(float x)
{

    //mumerically diffrentiates f() by finding gradient at point x
    
    return(f(x+delta)-f(x))/delta;
}
float intf(float x)
{
   
    //numerically integrates f() and plots it
    static float total=0;
    return (total+=(delta*f(x)));
}
*/
//////////////////////////////////////////////////////////////////////////////////////////////|SPHERE
/*
struct point_t
{//storing point vals
    float x;
    float y;
    float z;
};
void drawSphere(SDL_Renderer *renderer, int WindowWidth, sphere_t *spheres)
{
    float u;
    float v;
    for(int i = 0; spheres[i].r>0; i++)
    {//itterating through each sphere in the array
        for (u = 0; u<1; u+=0.02)
        {
            for (v = 0; v<1; v+=0.05)
            {   //go through  for UV points calcs
                point_t P = sphereP(u,v,spheres[i].r);
                P.x += spheres[i].xoffset;
                P.y += spheres[i].yoffset;
                P.z += spheres[i].zoffset;
                P.x/=P.z; //this puts the sphere into screen space
                P.y/=P.z;
                P.x*=300;
                P.y*=300;
            }
        }
    }
};
struct sphere_t
{//sphere items, radius, xyzposiioning offset
    float r;
    float xoffset;
    float yoffset;
    float zoffset;
};

point_t sphereP(float u, float v, float r)
{//calculations for the sphere from fomulas from slides provided 
   point_t P;
    float rr;
    rr = r*cos(M_PI*(v-0.5));
    P.x = rr*cos(2*M_PI*u);
    P.y = rr*sin(2*M_PI*u);
    P.z = r*sin(M_PI*(v-0.5));
    return P;
}

void drawSphere(SDL_Renderer *renderer, int WindowWidth, sphere_t *spheres)
{
    float u;
    float v;
    for(int i = 0; spheres[i].r>0; i++)
    {//itterating through each sphere in the array
        for (u = 0; u<1; u+=0.02)
        {
            for (v = 0; v<1; v+=0.05)
            {   //go through  for UV points calcs
                point_t P = sphereP(u,v,spheres[i].r);
                P.x += spheres[i].xoffset;
                P.y += spheres[i].yoffset;
                P.z += spheres[i].zoffset;
                P.x/=P.z; //this puts the sphere into screen space
                P.y/=P.z;
                P.x*=300;
                P.y*=300;
                if(P.z > 0)
                {
                    putPixel(renderer, P.x+WindowWidth/2, P.y+WindowWidth/2, P.z, 125, (int)P.z%255);
                };
                
            }     
        } 
    }
         
}
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////RAY TRACE SPHERES
void putPixel(SDL_Renderer *renderer, float x, float y, unsigned char r, unsigned char g, unsigned char b)
{
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}
struct point_t
{
    float x;
    float y;
    float z;
};
struct vec_t
{
    float x;
    float y;
    float z;
};
struct color_t
{
    float r;
    float g;
    float b;
};
struct sphereRay_t
{
    struct point_t center;
    float r;
    struct color_t color;
};
/*struct hit_t
{
    //sphere ray trace as a solid color updated  to a NEW hit//////////////////////////////////////NOTE/////////////////////////RAY TRACE SPHERE-SOLID COLOR NOTE
    int hit;
    struct color_t color;
    float dist;
};*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////RAY TRACE SPHERE-NI SHADING
struct hitNI_t {
    int hit;
    float dist;
    sphereRay_t obj;//changed color store to what obj is hit
    };
float dot(vec_t a, vec_t b)
{//dot product of two x y z vals in this instance two vectors L (subraction of camera orgin and obj center) and direction based on window
    return(a.x*b.x+a.y*b.y+a.z*b.z);
}
vec_t pointSub(point_t a, point_t b)
{//subtacting camera center and sphere center in this instance, returns the vector result of this subtraction to use later in trace Obj
    vec_t result = {a.x-b.x, a.y-b.y, a.z-b.z};
    return result;
}
point_t pointPlusVector(point_t a, vec_t b)
{//adds point and vect x y z values together
    a.x += b.x;
    a.y += b.y;
    a.z += b.z;
    return a;
}
vec_t vectorScale(float x, vec_t v)
{//scales up the vactor by x ammount and returns the new vector
    v.x *= x;
    v.y *= x;
    v.z *= x;
    return v;
}
vec_t normalise(vec_t v)
{//normalization process,allows sphere to be seen correctly
//formula divide x y and z by sqrt( vx^2+vy^2+vz^2 ) and returns sesulting vector
    float length = sqrt(v.x*v.x+v.y*v.y+v.z*v.z);
    vec_t result = {v.x/length, v.y/length, v.z/length};
    return result;
}
// hit returned for the trace obj and (orgin, direction, obj) ordered
hitNI_t traceObj(struct point_t src,struct vec_t dir, struct sphereRay_t obj)
{//see slide 15 02 Basic surfaces
    //most of the work
    //test if ray hits at all  and return constant color , disk of color should show
    hitNI_t h;//initializes our hit
    vec_t L = pointSub(obj.center, src);//preps formula center sphere minus camera center (0,0,0)
    float tca = dot(L,dir);//dot product of L and direction of the ray
    float d = sqrt(dot(L,L)-tca*tca);//(objcenter-camCenter).(objcenter-camCenter)-((objcenter-canCenter).dir)2
    if(obj.r>d)
    {//if the ray is within the bounds of the radius of the sphere it hits, changes hit distance for later comparison 
        h.hit = 1;
        float thc = sqrt(obj.r*obj.r - d*d);
        h.dist = tca - thc;
    }
    else h.hit= 0;//if d is grater than radius then it wont draw and it will be left to a black screen
    h.obj = obj;//obj hit is assigned
    return h;//return if obj is hit, what obj, and the distance its hit, if not hit then wont draw, no obj hit and 0 distance
}
float shadeObj(point_t src, float hDist, vec_t direction, sphereRay_t obj)
{//NI Shading  formila locted on  slide 15  on 03 Geometry and Normals
//I=P-C
//I=Point-cam center
//Point= cam center+ scaling the normalized direction by hit distance
//N=objCenter-point
//V=-I/|I|
//N.V
    //I=P-C prep

    //Finding point P on sphere means P=camera position + hit distance*normalized direction
    point_t P = pointPlusVector(src, vectorScale(hDist, normalise(direction)));
    //finds the vector N which is point - cam center 
    vec_t N = pointSub(obj.center, P);
    //normalize N by dividing each component by radius of the sphere
    N.x /= obj.r;
    N.y /= obj.r;
    N.z /= obj.r;

    //I=P-C or point minus cam center
    vec_t I = pointSub(P, src);

    //normalize I to prep for V=-I/|I|
    vec_t V = normalise(I);
    //viewing direction vector inverted though -I
    //V=-I/|I|
    V = {V.x * -1, V.y * -1, V.z * -1};
    //N dot V
    float NV = dot(N,V);
    //printf("%f \n", NV);
    if(NV<0)//flip
        NV*=-1;
    return NV;//returns positive N.V
}
void drawScene(SDL_Renderer *renderer, int WindowWidth, int WindowHeight, point_t src, sphereRay_t *spheres)
{
    float x;
    float y;
    sphereRay_t obj;
    float hDist;
    vec_t direction;
    for(x=0; x<WindowWidth; x++)
    {
        for (y=0; y<WindowHeight; y++)
        {//loop through all pixels to go through on the screen
            hitNI_t closestHit;
            closestHit.hit = 0;// preset no hit and closest hit distance is far back 
            closestHit.dist = 9999;
            for(int i = 0; spheres[i].r>0; i++)
            {//each sphere in array
            //calc direction from cam to current pixel
                direction = normalise({x-WindowWidth/2,y-WindowHeight/2,500});
                //shoot a ray and see if it hits
                hitNI_t h = traceObj(src, direction, spheres[i]);        
                if(h.hit){//if it hits AND is the closent distance assign that object, object distance and such as closest hit
                    if (h.dist < closestHit.dist){
                        obj = h.obj;
                        hDist = h.dist;
                        //confirms that there is a close hit 
                        closestHit.hit = 1;
                        closestHit.dist = h.dist;
                    }
                } 
            }
            if (closestHit.hit){// closest obj
                float NV = shadeObj(src, hDist, direction, obj);//returns N.V of obj
                putPixel(renderer,x,y, obj.color.r * NV, obj.color.g * NV, obj.color.b * NV);//colors based on NI shading 
            }
        }
    }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
auto main() -> int
{
    constexpr int WindowWidth = 700;
    constexpr int WindowHeight = 700;
    SDL_Event event;
    SDL_Renderer *renderer;
    SDL_Window *window;
    SDL_Surface* image;
    int i;
    //TASK 3
    SDL_Surface* pScreenShot = SDL_CreateRGBSurface(0, WindowWidth, WindowHeight, 32, 0x00ff0000, 0x0000ff00, 0x000000ff, 0xff000000);//preps surface to bmp//HERE
    std::random_device rd;
    std::mt19937 gen(rd());
    // create a distribution to produce our 2d points
    std::uniform_int_distribution<> width_dist(0, WindowWidth - 1);
    std::uniform_int_distribution<> height_dist(0, WindowHeight - 1);
    // create a distribution to produce our colour range
    // note windows does not allow an unsigned char dist see
    // https://stackoverflow.com/questions/31460733/why-arent-stduniform-int-distributionuint8-t-and-stduniform-int-distri
    std::uniform_int_distribution<unsigned short> colour_dist(0, 255);
    SDL_Init(SDL_INIT_VIDEO);
    SDL_CreateWindowAndRenderer(WindowWidth, WindowHeight, 0, &window, &renderer);
    SDL_SetWindowTitle(window, "Put Pixel : Sphere Render");
    // clear to background
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    bool quit = false;
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);
    ///////////////////////////////////////////////////////////Done in Purple

    //SDL_SetRenderDrawColor(renderer, 140, 30, 140, 255);
    //////////////////////////////////////////////////////////////////////////TASK1

    //SDL_RenderDrawLine(renderer,20,20,20,80);
    ////////////////////////////////////////////////////////////////////////////////////TASK 2

    //drawBox(renderer,20,100,100, 150);
    //////////////////////////////////////////////////////////////////////////////////////////////TASK 4

    /*for(float x=0;x<WindowWidth;++x)
        {
            putPixel(renderer,x,(f(x/360*M_PI*2))*100+150,90,0,0);
        }
    for(float x=0;x<WindowWidth;++x)
        {
            putPixel(renderer,x,(df(x/360*M_PI*2))*100+150,90,0,0);
        }
              
        */
    ///////////////////////////////////////////////////////////////////////////////////////SPHERE and SPHERE ARRAY
    /*
    //creates an array of spheres and draws the spheres through points 
    sphere_t spheres[] = { {25,-50,0,200},
                        {50,100,-50,200},
                        {50,25,25,200},
                        {10,40,100,200},
                        {30,10,100,200},
                       {0,0,0,0}};
    drawSphere(renderer, WindowWidth, spheres);*/
    ///////////////////////////////////////////////////////////////////////////////////////RAY TRACE SPHERE-SOLID COLOR
    //draws sphere as blue circle
    //preps the scene
    /*
    float x;
    float y;RAY TRACE SPHERE-NI SHADING
    point_t origin = {0,0,0};//cam origin
    sphereRay_t obj;
    obj.center= {0,0,30};
    obj.r = 10;
    //raytrace sphere
    for(x=0; x<WindowWidth; x++)
    {
        for (y=0; y<WindowHeight; y++)
        {//direction of ray for each pixel
            vec_t direction = {x-WindowWidth/2,y-WindowHeight/2,500};
            //normalize (important) or else you won't be able to see the sphere
            direction = normalise(direction);
            //cam orgin direction vector and obj vals to determine if there is a hit
            hit_t h = traceObj(origin, direction, obj);        
            if(h.hit)//color pixel if it is a hit
                putPixel(renderer,x,y,h.color.r,h.color.g,h.color.b);
        }
    }*/
    ///////////////////////////////////////////////////////////////////////////////////////////RAY TRACE SPHERE-NI SHADING
    point_t origin = {0,0,0};
    sphereRay_t spheres[] = { {{0,0,30},10,{255,0,0}},
                           {{0,10,40},10,{0,255,0}},
                           {{0,-10,30},10,{0,0,255}},
                           {{0,0,0},0,{0,0,0}}};
    //raytrace objects
    drawScene(renderer, WindowWidth, WindowHeight, origin, spheres);
    //render
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        SDL_RenderPresent(renderer);
        // wait 100 ms
        SDL_Delay(100);
    
        while (!quit)
    {

        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            // this is the window x being clicked.
            case SDL_QUIT:
                quit = true;
                break;
            // now we look for a keydown event
            case SDL_KEYDOWN:
            {
                switch (event.key.keysym.sym)
                {
                // if it's the escape key quit
                case SDLK_ESCAPE:
                    quit = true;
                    break;
                //TASK 3
                case SDLK_s://pressing s results in saving bitmap
                    if(pScreenShot)
                    {
                        // Read the pixels from the current render target and save them onto the surface
                        SDL_RenderReadPixels(renderer, NULL, SDL_GetWindowPixelFormat(window), pScreenShot->pixels, pScreenShot->pitch);

                        // Create the bmp screenshot file
                        SDL_SaveBMP(pScreenShot, "Screenshot.bmp");
                        // Destroy the screenshot surface
                        SDL_FreeSurface(pScreenShot);
                    } 
                    break;
                default:
                    break;
                } // end of key process
            }     // end of keydown
            break;
            default:
                break;
            } // end of event switch
        }     // end of poll events
        // clear to black
    // clean up
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return EXIT_SUCCESS;
}