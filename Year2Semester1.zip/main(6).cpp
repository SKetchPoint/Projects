#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <cmath>
#include <math.h>
#include <SDL_image.h>

float f(float x)
//sinc
{
    return sin(x)/x;
}

float pdf(float x)
//probability distribution function
{
    float v = 1-(x/M_PI);
    return v*(2/M_PI);
}

float random1()
//random number between 0 and 1
{
    return ((random()%10000)+0.5)/10000.0;
}

auto main() -> int
{
    //srand(time(NULL));
    float i;
    float count = 0;
    float total = 0;
    float samples = 100;
    for (i = 1; i <= samples; i++)
    {  
        
        float x = (rand()%int(samples))/samples*M_PI; //uniform random sample
        float px = pdf(x); //probability of taking a sample
        float val = (random1()*(2/M_PI)); //random number between 0 and 1 * max value of pdf
        if(val<px){ //pdf test
            count++; //how many times has the sample passed through pdf test
            total += f(x)/px;
            printf("%f, %f \n", i, total/count);
        }
    }
}