#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <cmath>

// Define the sinc function
float f(float x)
{
    return sin(x) / x;
}

// Define the probability distribution function for importance sampling using cosine
float pdf_cos(float x)
{
    return 0.5 * cos(x / 2);
}
// Define the probability distribution function for uniform sampling
float pdf_uniform(float x)
{
    float v = 1 - (x / M_PI);
    return v * (2 / M_PI);
}

float random1()
{
    return ((rand() % 10000) + 0.5) / 10000.0;
}

void importance(float (*pdf)(float), float maxP)
{
    float tot = 0;
    for (int i = 0; i < 100; i++)
    {
        float x;
        float px;
        do
        {
            x = random1() * M_PI;
            px = pdf(x);
        } while (random1() * maxP > px);

        tot += f(x) / px;
        printf("%d:%f:%f\n", i + 1, x, tot / (i + 1));
    }
}

void uniformDistribution()
{
    srand(time(NULL));
    float i;
    float count = 0;
    float total = 0;
    float samples = 100;
    for (i = 1; i <= samples; i++)
    {  
        float x = (rand()%int(samples))/samples*M_PI; //uniform random sample
        float px = pdf_uniform(x); //probability of taking a sample
        float val = (random1()*(2/M_PI)); //random number between 0 and 1 * max value of pdf
        if(val<px){ //pdf test
            count++; //how many times has the sample passed through pdf test
            total += f(x)/px;
            printf("%f, %f \n", i, total/count);
        }
    }
}

auto main() -> int
{
    //uniformDistribution();
    importance(pdf_cos, 0.5); // Use either pdf_cos or pdf_sinc for importance sampling
}