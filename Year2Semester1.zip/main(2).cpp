#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif

#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <random>

struct point_t {
    int x;
    int y;
    point_t(int _x, int _y) : x(_x), y(_y) {}
};

struct vec_t {
    float x;
    float y;
};

point_t lerp(point_t p0, point_t p1, float t) {
    point_t pa(0, 0);
    pa.x = (1 - t) * p0.x + t * p1.x;
    pa.y = (1 - t) * p0.y + t * p1.y;
    return pa;
}

point_t lerpQuadratic(point_t p0, point_t p1, point_t p2, float t) {
    point_t pA0 = lerp(p0, p1, t);
    point_t pA1 = lerp(p1, p2, t);
    return lerp(pA0, pA1, t);
}

point_t lerpCubic(point_t p0, point_t p1, point_t p2, point_t p3, float t) {
    point_t pA0 = lerp(p0, p1, t);
    point_t pA1 = lerp(p1, p2, t);
    point_t pA2 = lerp(p2, p3, t);

    point_t pB0 = lerp(pA0, pA1, t);
    point_t pB1 = lerp(pA1, pA2, t);

    return lerp(pB0, pB1, t);
}

void putPixel(SDL_Renderer* renderer, int x, int y, unsigned char r, unsigned char g, unsigned char b) {
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}

//draws out each point 
void drawCurves(SDL_Renderer* renderer, const std::vector<point_t>& points) {
    for (const point_t& point : points) {
        putPixel(renderer, point.x, point.y, 255, 255, 255);
    }
}

int main() {
    const int WindowWidth = 700;
    const int WindowHeight = 500;

    SDL_Event event;
    SDL_Renderer* renderer;
    SDL_Window* window;

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> width_dist(0, WindowWidth - 1);
    std::uniform_int_distribution<> height_dist(0, WindowHeight - 1);
    std::uniform_int_distribution<unsigned short> colour_dist(0, 255);

    SDL_Init(SDL_INIT_VIDEO);
    SDL_CreateWindowAndRenderer(WindowWidth, WindowHeight, 0, &window, &renderer);
    SDL_SetWindowTitle(window, "Bezier Curves");

    //creates vectors from each point and initialises list of points
    std::vector<point_t> quadraticPoints;
    std::vector<point_t> cubicPoints;
    //point declaration, change these for different curves!
    point_t p0(30, 100);
    point_t p1(10, 200);
    point_t p2(600, 500);
    point_t p3(400, 400);

    //Creates points for a cubic Bezier curve, uses 4 points
    for (int i = 0; i <= 300; i++) {
        float t = static_cast<float>(i) / 300;
        cubicPoints.push_back(lerpCubic(p0, p1, p2, p3, t)); //creates a series of points for the renderer to draw, corresponding to the lerped points added initialized above^
    }
    //Creates points for a cubic Bezier curve, uses 3 points (not p3)
    for (int i = 0; i <= 300; i++) {
        float t = static_cast<float>(i) / 300;
        quadraticPoints.push_back(lerpQuadratic(p0, p1, p2, t)); //creates a series of points for the renderer to draw, corresponding to the lerped points added initialized above^
    }

    while (true) {
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    SDL_DestroyRenderer(renderer);
                    SDL_DestroyWindow(window);
                    SDL_Quit();
                    return EXIT_SUCCESS;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        SDL_DestroyRenderer(renderer);
                        SDL_DestroyWindow(window);
                        SDL_Quit();
                        return EXIT_SUCCESS;
                    }
                    break;
                default:
                    break;
            }
        }

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
        SDL_RenderClear(renderer);
        //calling functions for drawing out the curves
        //drawCurves(renderer, cubicPoints);
        drawCurves(renderer, quadraticPoints);
        
        SDL_RenderPresent(renderer);
    }
}
