#ifdef WIN32
#define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include <random>
#include <math.h>

void putPixel(SDL_Renderer *renderer, float x, float y, unsigned char r, unsigned char g, unsigned char b)
{
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_RenderDrawPoint(renderer, x, y);
}

struct vec_t
{
    float x;
    float y;
};

vec_t randomgradient(int ix, int iy)
{
    const unsigned w = 8*sizeof(unsigned);
    const unsigned s = w/2;
    unsigned a = ix, b = iy;
    a *= 3284157443;

    b ^= a << s | a >> w - s;
    b *= 1911520717;

    a ^= b << s | b >> w - s;
    a *= 2048419325;
    float random = a*(M_PI/~(~0u>>1));

    vec_t v;
    v.x = sin(random);
    v.y = cos(random);

    return v;
}

float dotGridGradient(int ix, int iy, float x, float y)
{
    vec_t gradient = randomgradient(ix,iy);

    float dx = x - (float)ix;
    float dy = y - (float)iy;

    return (dx *gradient.x + dy * gradient.y);
}

float interpolate(float a0, float a1, float w)
{
    return (a1 - a0)*(3.0-w*2.0)*w*w+a0;
}

float perlin(float x, float y)
{
    int x0 = (int)x;
    int y0 = (int)y;
    int x1 = x0 + 1;
    int y1 = y0 + 1;

    float sx = x - (float)x0;
    float sy = y - (float)y0;

    float n0 = dotGridGradient(x0,y0,x,y);
    float n1 = dotGridGradient(x1,y0,x,y);
    float ix0 = interpolate(n0,n1,sx);

    n0 = dotGridGradient(x0,y1,x,y);
    n1 = dotGridGradient(x1,y1,x,y);
    float ix1 = interpolate(n0,n1,sx);

    float value = interpolate(ix0, ix1, sy);

    return value;
}

auto main() -> int
{
    constexpr int WindowWidth = 1000;
    constexpr int WindowHeight = 700;
    SDL_Event event;
    SDL_Renderer *renderer;
    SDL_Window *window;
    float x;
    std::random_device rd;
    std::mt19937 gen(rd());
    // create a distribution to produce our 2d points
    std::uniform_int_distribution<> width_dist(0, WindowWidth - 1);
    std::uniform_int_distribution<> height_dist(0, WindowHeight - 1);
    // create a distribution to produce our colour range
    // note windows does not allow an unsigned char dist see
    // https://stackoverflow.com/questions/31460733/why-arent-stduniform-int-distributionuint8-t-and-stduniform-int-distri
    std::uniform_int_distribution<unsigned short> colour_dist(0, 255);
    SDL_Init(SDL_INIT_VIDEO);
    SDL_CreateWindowAndRenderer(WindowWidth, WindowHeight, 0, &window, &renderer);
    SDL_SetWindowTitle(window, "Noise");
    // clear to background
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    bool quit = false;

    // clear to black
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);
    // now draw coloured pixels
    const int gridsize = 700;

    for (int x = 0; x < WindowWidth; x++)
    {
        for (int y = 0; y < WindowHeight; y++)
        {
            int index = (y * WindowWidth + x)*4;
            float val = 0;
            float freq = 1;
            float amp = 1;

            for (int i = 0; i < 12; i++)
            {
                val += perlin(x*freq/gridsize, y*freq/gridsize)*amp;
                freq*=2;
                amp/=2;
            }

            val *= 1.2;

            if(val > 1.0f)
                val = 1.0f;
            else if (val < -1.0f)
                val = -1.0f;

            int color = (int)(((val+1.0f)*0.5f)*255);

            putPixel(renderer, x, y, color, color, color);
        }
    }

    while (!quit)
    {

        while (SDL_PollEvent(&event))
        {
            switch (event.type)
            {
            // this is the window x being clicked.
            case SDL_QUIT:
                quit = true;
                break;
            // now we look for a keydown event
            case SDL_KEYDOWN:
            {
                switch (event.key.keysym.sym)
                {
                // if it's the escape key quit
                case SDLK_ESCAPE:
                    quit = true;
                    break;
                default:
                    break;
                } // end of key process
            }     // end of keydown
            break;
            default:
                break;
            } // end of event switch
        }     // end of poll events

        // flip buffers
        SDL_RenderPresent(renderer);
        // wait 100 ms
        SDL_Delay(100);
    }
    // clean up
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return EXIT_SUCCESS;
}